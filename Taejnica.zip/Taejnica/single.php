<?php get_header();?>

<div class="containerForHeaderIMGPage searchPage" style="margin-bottom: 50px; background: url(<?php the_post_thumbnail_url()?>) no-repeat center / cover;">
    <div class="blockBgColor"></div>
    <div class="container blockTextHeaderPageHome ">
        <div class="row">
            <div class="col">
                <div class="blockContentHeaderPageHome searchPage">
                    <h2><?php
                        the_title();

                        echo('<br />');

                        if (has_excerpt()) {
                            the_excerpt();
                        }
                        else {};

                        ?>
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container" style="margin-bottom: 30px;">
    <div class="row">
        <main class="col-lg-8">

            <?php
            while (have_posts()):
                the_post();

                get_template_part('template-parts/content', get_post_type());

                the_post_navigation(
                    array(
                        'prev_text' => '<span class="nav-subtitle fontFamilyMiniBw">' . esc_html__('Предыдущая запись:', 'taejnica') . '</span> <span class="nav-title fontFamilyMiniBw">%title</span>',
                        'next_text' => '<span class="nav-subtitle fontFamilyMiniBw">' . esc_html__('Следующая запись:', 'taejnica') . '</span> <span class="nav-title fontFamilyMiniBw">%title</span>',
                    )
                );

                // If comments are open or we have at least one comment, load up the comment template.
                if (comments_open() || get_comments_number()):
                    comments_template();
                endif;

            endwhile; // End of the loop.
            ?>
        
        </main><!-- #main -->
  
        <?php get_sidebar()?>
  </div>
</div>

<?php get_footer();?>