<? 
get_header();
?>

<h1>Страница SPA-меню</h1>

<? get_footer(); ?>