<div class="col-lg-4">
    <?php if (!dynamic_sidebar('sidebar-blog')):

        dynamic_sidebar('sidebar-blog');

    endif;?>
</div>