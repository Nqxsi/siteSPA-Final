<?php get_header();?>
<?php the_content();?>

<div class="container" id="contTeam">
    <div class="row text-center">
        <div class="col-12">
            <div class="headerOurTeam">
                <h1><?php echo get_post_meta($post->ID, 'ourTeamTitle', true) ?>
                </h1>
                <br />
                <h2>
                    <?php echo get_post_meta($post->ID, 'ourTeamPopTitle', true) ?>
                </h2>
            </div>
        </div>
    </div>
    <?php echo get_template_part('template-parts/content', 'staff'); ?>
</div>

<?php get_footer(); ?>