<?php get_header();?>

<div class="containerForHeaderIMGPage searchPage" style="height:auto;">
    <div class="blockBgColor"></div>
    <div class="container blockTextHeaderPageHome ">
        <div class="row">
            <div class="col">
                <div class="blockContentHeaderPageHome searchPage">
                    <h2>
                        Ошибка 404
                    </h2>
                    <p>Такой страницы не&nbsp;существует</p>
                    <p>
                        Вы пытаетесь зайти на страницу, которой нет. Воспользуйтесь поиском или перейдите на главную страницу.
                    </p>

                    <?php the_widget('WP_Widget_Search')?>

                    <a href="/" class="backOnMain">Перейти на главную</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer();?>