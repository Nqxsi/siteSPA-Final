<? get_header(); ?>


<!-- block bg header -->

<div class="containerForHeaderIMGPage">
    <div class="blockBgColor"></div>
    <div class="container blockTextHeaderPageHome">
        <div class="row">
            <div class="col">
                <div class="blockContentHeaderPageHome">
                    <h2>
                    <?php 
                        if(is_category()){
                            echo __('Рубрика <br>') . get_queried_object()->name;
                        }
                        if(is_tag()){
                            echo __('Записи с меткой <br>') . get_queried_object()->name;
                        }
                        if(is_author()){
                            echo __('<small>Записи автора</small><br> ') . get_the_author_meta('display_name');
                        }
                        if(is_date()){
                            echo __('<small>Записи по дате</small><br> ') . get_the_date('j F Y');
                        }

                    ?>
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- block one post -->

<div class="container PageStudyBlog">
    <div class="row">
        <div class="col-lg-8">
            <div class="row">
                <?php $count = 0;
                if (have_posts()):
                    while (have_posts()):
                        the_post();
                        $count++;

                        switch ($count) {
                            case "1": ?>
                                <div class="col-lg-12">
                                    <div class="blockAuthorAndDate">
                                        <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                                            <?php the_author(); ?>
                                        </a>
                                        <p>
                                            <?php the_time('j F Y'); ?>
                                        </p>
                                    </div>
                                    <div class="contentBlogPost">
                                        <a href="<?php echo get_the_permalink(); ?>" class="h4 headerTextBlogPost">
                                            <?php the_title(); ?>
                                        </a>
                                        <p>
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                    <a href="<?php echo get_the_permalink(); ?>" class="readMore">Смотреть</a>
                                    <hr>
                                </div>
                                <?php
                                break;
                            default: ?>
                                <div class="col-lg-6">
                                    <div class="blockAuthorAndDate">
                                        <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                                            <?php the_author(); ?>
                                        </a>
                                        <p>
                                            <?php the_time('j F Y'); ?>
                                        </p>
                                    </div>
                                    <div class="contentBlogPost">
                                        <a href="<?php echo get_the_permalink(); ?>" class="h4 headerTextBlogPost">
                                            <?php the_title(); ?>
                                        </a>
                                        <p>
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                    <a href="<?php echo get_the_permalink(); ?>" class="readMore">Смотреть</a>
                                    <hr>
                                </div>

                                <!-- Вывод постов, функции цикла: the_title() и т.д. -->

                        <?php }endwhile; else: ?>
                    Записей нет.
                <?php endif; ?>
            </div>

            <!-- навигация по записям постов -->
            
            <?php the_posts_pagination(
                array(
                    'prev_text' => __('<span class="p-2">« Назад</span>'),
                    'next_text' => __('<span class="p-2">Следующая »</span>'),
                    'before_page_number' => '<span class="p-2">',
                    'after_page_number' => '</span>'
                )
            ); ?>
        </div>

        <!-- right sidebar -->
        
        <aside class="col-lg-4">
            <?php if (!dynamic_sidebar('sidebar-blog')):

                dynamic_sidebar('sidebar-blog');

            endif; ?>

        </aside>
    </div>
</div>


<? get_footer(); ?>