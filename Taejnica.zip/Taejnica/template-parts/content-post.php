<!-- Блог пост контент -->


<div class="blockAuthorAndDate">
    <p>
        <?php the_author(); ?>
    </p>
    <p>
        <?php the_time('j F Y'); ?>
    </p>
</div>

<?php the_content(); ?>