<!-- block with personal -->
<div class="container">
    <div class="row">
        <?php
        global $post;

        $query = new WP_Query([
            'posts_per_page' => 3,
            'post_type' => 'personal',
        ]);

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                ?>
                <div class="col-12 col-lg-4 col-sm-6">
                    <div class="blockCardTeam">
                        <img src="<?php the_post_thumbnail_url() ?>" alt="" />
                        <br /><br />
                        <div class="headerTextTeam">
                            <h2><?php the_title();?></h2>
                            <h3>
                                <?php the_excerpt();?>
                            </h3>
                        </div>
                        <hr />
                        <p>
                            <?php the_content();?>
                        </p>
                    </div>
                </div>


                <!-- Вывод постов, функции цикла: the_title() и т.д. -->
                <?php
            }
        } else {
            // Постов не найдено
        }

        wp_reset_postdata(); // Сбрасываем $post
        ?>
    </div>
</div>