<!-- service -->
<div class="container">
    <div class="row">
        <?php
        global $post;

        $query = new WP_Query([
            'posts_per_page' => 3,
            'post_type' => 'service',
        ]);

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                ?>
                <div class="col-12 col-md-6 col-lg-3 col-sm-12">
                    <img src="<?php the_post_thumbnail_url() ?>" alt="" style="width: 100%;">
                    <div class="col-12 blockTextService lineHR fontFamilyMiniBw mt-4">
                        <p class="fontFamilyBw">
                            <?php the_title(); ?>
                        </p>
                        <p class="fontFamilyMiniBw">
                            <?php the_excerpt(); ?>
                        </p>
                    </div>
                </div>



                <!-- Вывод постов, функции цикла: the_title() и т.д. -->
                <?php
            }
        } else {
            // Постов не найдено
        }

        wp_reset_postdata(); // Сбрасываем $post
        ?>
    </div>
</div>