<!-- carousel block -->

<div class="carousel slide" id="carouselControls" data-bs-ride="carousel">

    <div class="carousel-inner shadow-lg bg-body-tertiary">
        <?php
        global $post;

        $cnt = 0;
        $query = new WP_Query([
            'posts_per_page' => 5,
            'post_type' => 'sliderShow',
        ]);
        ?>
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselControls" data-bs-slide-to="0" class="active"
                aria-current="true"></button>

            <?php
            for ($i = 1; $i < count($query->posts); $i++) {
                ?><button type="button" data-bs-target="#carouselControls"
                    data-bs-slide-to="<?php echo $i ?>"></button>
                <?php
            }
            ?>
        </div>
        <?php
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $cnt++;
                switch ($cnt) {
                    case "1": ?>
                        <div class="carousel-item active">
                            <div class="d-block w-100 img-fluid"
                                style="background-image: url(<?php the_post_thumbnail_url(); ?>); height: 600px;">
                            </div>
                            <div class="t-cover_filter"></div>
                            <div class="carousel-caption d-none d-md-block">
                                <h5>
                                    <?php the_title(); ?>
                                </h5>
                                <p>
                                    <?php if (has_excerpt()) {
                                        the_excerpt();
                                    } ?>

                                </p>
                                <p>
                                    <?php the_content(); ?>
                                </p>
                                <br /><br />
                                <a class="aCarousel" href="javascript:PopUpShow()">Записаться</a>
                            </div>
                        </div>
                        <?php
                        break;
                    default: ?>
                        <div class="carousel-item">
                            <div class="d-block w-100 img-fluid"
                                style="background-image: url(<?php the_post_thumbnail_url(); ?>); height: 600px;"></div>
                            <div class="t-cover_filter"></div>
                            <div class="carousel-caption d-none d-md-block">
                                <h5>
                                    <?php the_title(); ?>
                                </h5>
                                <p>
                                    <?php if (has_excerpt()) {
                                        the_excerpt();
                                    } ?>
                                </p>
                                <p>
                                    <?php the_content(); ?>
                                </p>
                            </div>
                        </div>
                        <?php
                        break;
                }
                ?>
                <!-- Вывод постов, функции цикла: the_title() и т.д. -->
                <?php

            }
        } else {
            // Постов не найдено
        }

        wp_reset_postdata(); // Сбрасываем $post
        ?>
    </div>
    <a class="carousel-control-prev" role="button" href="#carouselControls" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" role="button" href="#carouselControls" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </a>
</div>
</div>
</div>
</div>