<form role="search" method="get" id="searchform" action="<?php echo home_url('/') ?>" class="formSidebarPageStudy">
    <input type="text" placeholder="Введите текст для поиска" value="<?php echo get_search_query() ?>" name="s" id="s">
    <button type="submit">Найти</button>
</form>
