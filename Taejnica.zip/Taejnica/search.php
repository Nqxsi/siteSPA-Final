<?php get_header()?>

<div class="containerForHeaderIMGPage searchPage">
    <div class="blockBgColor"></div>
    <div class="container blockTextHeaderPageHome ">
        <div class="row">
            <div class="col">
                <div class="blockContentHeaderPageHome searchPage">
                    <h2><?php
                    /* translators: %s: search query. */
                    printf(esc_html__('Результаты поиска: %s', 'taejnica'), '<span>' . get_search_query() . '</span>');
                    ?></h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container PageStudyBlog">
    <div class="row">
        <div class="col-lg-8">
            <div class="row">
                <?php $count = 0;
                if (have_posts()):
                    while (have_posts()):
                        the_post();
                        $count++;

                        switch ($count) {
                            case "1": ?>

                                <div class="col-lg-12">
                                    <!-- <div class="miniIMGBlogPosts">
                                        <?php

                                        if (has_post_thumbnail()) { //проверка наличия миниатюры
                                            the_post_thumbnail('post-thumbnail', array('class' => "imgForBlogPost")); //вывод миниатюры
                                        } else { //если миниатюры нет
                                            echo '<img src = "' . get_template_directory_uri() . '/image/menuImg.png"/>';
                                        }
                                        ?>
                                    </div> -->
                                    <div class="blockAuthorAndDate">
                                        <p>
                                            <?php the_author(); ?>
                                        </p>
                                        <p>
                                            <?php the_time('j F Y'); ?>
                                        </p>
                                    </div>
                                    <div class="contentBlogPost">
                                        <a href="<?php echo get_the_permalink(); ?>" class="h4 headerTextBlogPost">
                                            <?php the_title(); ?>
                                        </a>
                                        <p>
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                    <a href="<?php echo get_the_permalink(); ?>" class="readMore">Смотреть</a>
                                    <hr>
                                </div>

                                <?php
                                break;
                            default: ?>

                                <div class="col-lg-6">
                                    <div class="blockAuthorAndDate">
                                        <p>
                                            <?php the_author(); ?>
                                        </p>
                                        <p>
                                            <?php the_time('j F Y'); ?>
                                        </p>
                                    </div>
                                    <div class="contentBlogPost">
                                        <a href="<?php echo get_the_permalink(); ?>" class="h4 headerTextBlogPost">
                                            <?php the_title(); ?>
                                        </a>
                                        <p>
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                    <a href="<?php echo get_the_permalink(); ?>" class="readMore">Смотреть</a>
                                    <hr>
                                </div>

                                <!-- Вывод постов, функции цикла: the_title() и т.д. -->
                        <?php }endwhile; else: ?>
                    Записей нет.
                <?php endif; ?>
            </div>
            <!-- навигация по записям постов -->
            <?php the_posts_pagination(
                array(
                    'prev_text' => __('<span class="p-2">« Назад</span>'),
                    'next_text' => __('<span class="p-2">Следующая »</span>'),
                    'before_page_number' => '<span class="p-2">',
                    'after_page_number' => '</span>'
                )
            ); ?>
        </div>
        <div class="col-lg-4">
            <?php if (!dynamic_sidebar('sidebar-blog')):

                dynamic_sidebar('sidebar-blog');

            endif;

            ?>
        </div>
    </div>
</div>

<?php get_footer()?>