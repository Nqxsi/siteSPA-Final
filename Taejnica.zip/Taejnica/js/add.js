//кнопка "наверх"
document.addEventListener('DOMContentLoaded', () => {
	var $backTop = $('.backTop')
	$(window).on('scroll', function () {
		if ($(window).scrollTop() >= 400) {
			$backTop.fadeIn()
		} else {
			$backTop.fadeOut()
		}
	})

	$backTop.on('click', function () {
		$('html,body').animate({ scrollTop: 0 }, 200)
	})
})
//дата в копирайте
document.addEventListener('DOMContentLoaded', () => {
	const year = document.getElementById('date')
	year.textContent = new Date().getFullYear()
})

// panel call
document.addEventListener('DOMContentLoaded', () => {
	const btnOpen = document.querySelector('.btnPanelOpen')
	const popUpPanelCall = document.querySelector('.popupPanelCall')
	const togglePanel = function () {
		popUpPanelCall.classList.toggle('popupPanelCallShow')
	}

	btnOpen.addEventListener('click', function (e) {
		e.stopPropagation()
		togglePanel()
	})

	(function () {
		$('.btnPanelOpen').animate(
			{
				scale: 1.3,
			},
			1500
		).animate(
			{
				scale: 1.0,
			},
			1500,
			arguments.callee)
	}());
	
})

// pupUp

function PopUpShow() {
	$('#popup1').fadeIn()
}

function PopUpHide() {
	$('#popup1').fadeOut()
}
