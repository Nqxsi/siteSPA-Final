<?
get_header();
?>

<?php the_content(); ?>

<?php echo get_template_part('template-parts/content','service');?>

<? get_footer(); ?>