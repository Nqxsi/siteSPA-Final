<?php if (!dynamic_sidebar('sidebar-footer')):

    dynamic_sidebar('sidebar-footer');

endif; ?>