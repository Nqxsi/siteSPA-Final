<? wp_head(); ?>

<!-- header -->

<body>
    <div class="container text-center">
        <div class="row justify-content-between">
            <div class="col-2 col-lg-1">
                <div class="imgSize">
                    <? if (has_custom_logo()) {
                        echo get_custom_logo();
                    } ?>
                </div>
            </div>
            <div class="col-9 col-lg-8 align-self-center">
                <div class="row align-items-center">
                    <div class="col-12 col-xl-4 col-lg-4 col-sm-6">
                        <div class="ConteinerHeaderPhoneIcon">
                            <div class="IconImgConteinerPhone">
                                <img src="/wp-content/themes/Taejnica/image/icon_call.png" alt="" />
                            </div>
                            <div class="NumberTelHeader">
                                <a href="tel:+79832606268">+7(983)260-62-68</a>
                                <br />
                                serebroAn@yandex.ru
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-4 col-lg-4 textIconGeo">
                        <div class="ConteinerHeaderPhoneIcon">
                            <div class="IconImgConteinerGeo">
                                <img src="/wp-content/themes/Taejnica/image/geolocation.png" alt="" />
                            </div>
                            <div class="NameGeo">
                                Г. Абакан, ул Жукова 77
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-xl-4 col-lg-4 col-sm-6 blockWhithA">
                        <a href="javascript:PopUpShow()">
                            <div class="ConteinerAForNumberHeader">
                                Заказать звонок
                            </div>
                        </a>
                        <a class="btn btn-primary" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button"
                            aria-controls="offcanvasExample">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- pupUP form -->

    <div class="b-popup" id="popup1">
        <a href="javascript:PopUpHide()"><i class="fa-solid fa-xmark"></i></a>
        <div class="container b-popup3">
            <div class="row justify-content-md-center align-items-center mt-5">
                <div class="col-6 mt-5">
                    <div class="blockFormPupUp">
                        <img class="imgFormPopUp" src="\wp-content\themes\Taejnica\image\forFormPopUp.jpg" alt="">
                        <div class="headerTextBlockFormPupUp text-center m-5">
                            <h2 class="fontFamilyBw HeaderCustomTextJS"><?php echo the_field('headerTextBlockFormPupUp', $post ->ID);?>Связаться со мной</h2>
                            <h3 class="fontFamilyMiniBw PopCustomTextJS">Укажите ваше имя и номер телефона</h3>
                        </div>
                        <!-- form message -->
                        <form target="_blank" class="formPopUp fontFamilyBw contact__form" method="POST" action="<?php echo admin_url( 'admin-ajax.php' )?>">
                            <input type="hidden" name="action" value="my_action">

                            <div class="alert alert-success contact__msg" style="display: none" role="alert">
                                <p>Ваша заявка успешно отправлена! Скоро мы с вами свяжемся</p>
                            </div>
                            
                            <input class="inputFormPopUp form-control" type="text" id="name" name="name" required placeholder="ИМЯ"/>
                            <input class="inputFormPopUp form-control" type="tel" id="phone" name="phone" required placeholder="ТЕЛЕФОН"/>
                            <div style="text-align: center;">
                                <input class="btnFormPopUp" type="submit" value="Отправить"/>
                                <br /><br />
                                <p>Нажимая на кнопку, вы даете согласие на обработку персональных данных и соглашаетесь c политикой конфиденциальности</p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

<!-- header menu -->

    <div class="header">
        <div class="contForBgMenu">
            <div class="blockBg"></div>
            <div class="container text-center">
                <div class="row justify-content-center align-self-center MenuHref">
                    <div class="col navMenu">
                        <? wp_nav_menu([
                            'theme_location' => 'header',
                            'container' => false,
                            'menu_class' => 'navBarUl',
                            'fallback_cb' => '__return_false',
                            'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                            'depth' => 2,
                            'walker' => new navMenuCustom()
                        ]);?>
                    </div>
                </div>
            </div>
        </div>
    </div>
