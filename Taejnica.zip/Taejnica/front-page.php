<?php get_header(); ?>
<!-- carousel in front page -->

<?php echo get_template_part('template-parts/content', 'sliderShow'); ?>
<br />

<!-- card works -->

<div class="container OurWork">
    <div class="row text-center">
        <div class="col-12">
            <p class="PHeader"><?php the_field('PHeader'); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-xxl-4 col-xl-6 col-lg-6 contentCardWork">
            <div class="cardWork">
                <div class="BgCardWork">
                    <img src="/wp-content/themes/Taejnica/image/img1OurWork.jpg" class="ImgCardWork" alt="" />
                </div>
                <div class="textContCardWork">
                    <div class="headerTextWork">
                        <h2>Массаж</h2>
                    </div>
                    <div class="mainTextWork">
                        <hr />
                        <p>Психолог вашего тела</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-xxl-4 col-xl-6 col-lg-6 contentCardWork">
            <div class="cardWork">
                <div class="BgCardWork">
                    <img src="/wp-content/themes/Taejnica/image/img2OurWork.jpg" class="ImgCardWork" alt="" />
                </div>
                <div class="textContCardWork">
                    <div class="headerTextWork">
                        <h2>SPA-меню</h2>
                    </div>
                    <div class="mainTextWork">
                        <hr />
                        <p>Гармония, здоровье и красота</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-xxl-4 col-xl-6 col-lg-6 contentCardWork">
            <div class="cardWork">
                <div class="BgCardWork">
                    <img src="/wp-content/themes/Taejnica/image/img3OurWork.jpg" class="ImgCardWork" alt="" />
                </div>
                <div class="textContCardWork">
                    <div class="headerTextWork">
                        <h2>Подарки для любимых</h2>
                    </div>
                    <div class="mainTextWork">
                        <hr />
                        <p>Для тех кто ценит натуральное и здоровое</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br />

<!-- block team -->

<div class="container" id="contTeam">
    <div class="row text-center">
        <div class="col-12">
            <div class="headerOurTeam">
                <h1><?php the_field('ourTeamTitle') ?></h1>
                <br />
                <h2>
                    <?php the_field('ourTeamPopTitle') ?>
                </h2>
            </div>
        </div>
    </div>
    <?php echo get_template_part('template-parts/content', 'staff'); ?>
</div>

<!-- block with numbers -->

<!-- <div class="background-green">
    <div class="container">
        <div class="row align-items-center justify-content-md-center ">
            <div class="col-md-4 ps-5">
                <div class="icon-numbers">
                    <i class="faNumber fa-solid fa-heart"></i>
                    <p><?php the_field('clientsT', $post->ID);?></p>
                </div>
                <p class="PTextNumber fontFamilyMiniBw">счастливых клиентов</p>
            </div>
            <div class="col-md-4 ps-5">
                <div class="icon-numbers">
                    <i class="faNumber fa-solid fa-star"></i>
                    <p><?php the_field('massageT');?></p>
                </div>
                <p class="PTextNumber fontFamilyMiniBw">видов массажа</p>
            </div>
            <div class="col-md-4 ps-5">
                <div class="icon-numbers">
                    <i class="faNumber fa-solid fa-user"></i>
                    <p><?php the_field('teamT');?></p>
                </div>
                <p class="PTextNumber fontFamilyMiniBw">людей в команде</p>
            </div>
            </div>
    </div>
</div> -->

<?php get_footer(); ?>