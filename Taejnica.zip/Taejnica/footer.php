<!-- side bar contacts info -->

<div class="container" id="contactscont">
	<div class="row">
		<div class="col-lg-5 col-12">
			<?php get_sidebar('contacts');?>
		</div>
		<div class="col-12 col-lg-7">
			<div class="blokMap">
				<script type="text/javascript" charset="utf-8" async
					src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Aa95d11c40d33fb99edfa9533093cf099d0b7d70c257fd6e794b209fa1a60284a&amp;width=100%&amp;height=400&amp;lang=ru_RU&amp;scroll=false"></script>
			</div>
		</div>
	</div>
</div>

<!-- footer -->

<footer>
	<?php get_sidebar('footer'); ?>
</footer>

<!-- btn go to top -->
<button class="backTop" title="GoToTop">&uarr;</button>
<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
	<div class="offcanvas-header">
		<img src="/wp-content/themes/Taejnica/image/LOGO.png" alt="" />
		<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
	</div>
	<div class="offcanvas-body">
		<div>
			<hr />
			<ul>
				<li>Акции</li>
				<li>Массаж</li>
				<li>SPA-меню</li>
				<li>Мастера</li>
				<li>Обучение</li>
				<li>Контакты</li>
			</ul>
		</div>
		<div class="offcanNumber">
			<a href="#"> +7(983) 260-62-68 </a>
			<p>
				&copy <span id="date">#</span> Organic SPA-Сибирское
				здоровье
			</p>
		</div>
	</div>
</div>

<!-- panel with contact form -->

<button class="btnPanelOpen" title="PanelCall"><img src="/wp-content/themes/Taejnica/image/icon_call.png" alt=""></button>
<div class="popupPanelCall">
	<div class="panelMultiBtn">
		<div class="blockIntoPanel">
			<div class="textHeaderPanelCall">
				<p class="HeaderCustomTextJS">
					Оставьте свой номер телефона и мы с свяжемся с вами!
				</p>
			</div>
			<form class="contact__form" action="<?php echo admin_url('admin-ajax.php') ?>" method="post">
				<input type="hidden" name="action" value="my_action">

                <div class="alert alert-success contact__msg" style="display: none" role="alert">
                    <p>Ваша заявка успешно отправлена! Скоро мы с вами свяжемся</p>
                </div>

				<div class="blockWithInputBtn">
					<div class="blockInputForm">
						<input class="form-control" type="tel" id="phone" name="phone" placeholder="+7 983 999 - 99 - 99" required><br>
					</div>
					<div class="blockBtnForm">
						<input type="submit" style="background-color: #199c68;" value="Перезвонить"/>
					</div>
				</div>
			</form>
			<div class="textContentPanelCall">
				<p>
					Или вы можете позвонить нам <br>+7 (983) 777-77-77
				</p>
				<p>
					Нажимая на кнопку, вы даете согласие на обработку персональных данных и соглашаетесь c политикой
					конфиденциальности
				</p>
			</div>
		</div>
	</div>
</div>
<? wp_footer(); ?>
</body>

</html>