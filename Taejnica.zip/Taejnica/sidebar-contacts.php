    <?php if (!dynamic_sidebar('sidebar-contacts')):

        dynamic_sidebar('sidebar-contacts');

    endif; ?>