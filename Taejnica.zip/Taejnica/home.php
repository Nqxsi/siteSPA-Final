<? get_header(); ?>

<!-- Block bg header -->

<div class="containerForHeaderIMGPage">
    <div class="blockBgColor"></div>
    <div class="container blockTextHeaderPageHome">
        <div class="row">
            <div class="col">
                <div class="blockContentHeaderPageHome">
                    <h2>
                        <?php the_field('HeaderText'); ?>ОБУЧЕНИЕ
                    </h2>
                    <p>На базе нашего SPA-салона проводится <br> обучение мастеров массажа. <br>
                        После прохождения курса вы сможете освоить <br> новую прибыльную профессию и стать <br>
                        востребованным специалистом.
                    </p>
                </div>
                <div class="blockButtonHeaderPageHome">
                    <svg role="presentation" class="t581__arrow-icon arrowPageHome " style="fill:#ab3a3a; "
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 180">
                        <path
                            d="M54.1 108c-.5 0-.9-.2-1.2-.6-.5-.7-.3-1.6.4-2.1 1.5-1 9.5-5.5 14.6-8.3-17.4-.5-31.3-7.3-41.3-20C9.9 55.7 9.5 24.2 14.2 3.7c.2-.8 1-1.3 1.8-1.1.8.2 1.3 1 1.1 1.8-4.6 19.9-4.2 50.3 11.8 70.8 9.5 12.2 23 18.6 39.9 18.9h.3l-3.2-4c-1.4-1.7-2.7-3.3-4.1-5.1-.7-.9-1.5-1.9-2.3-2.9-.5-.6-.4-1.6.2-2.1.6-.5 1.6-.4 2.1.2 0 0 0 .1.1.1l6.4 7.9c.5.6.9 1.1 1.4 1.7 1.5 1.8 3.1 3.6 4.3 5.5 0 .1.1.1.1.2.1.2.1.3.2.5v.3c0 .2 0 .3-.1.5 0 .1-.1.1-.1.2-.1.2-.2.3-.3.4-.1.1-.2.1-.3.2 0 0-.1 0-.2.1-.9.4-16 8.6-18.2 10.1-.4 0-.7.1-1 .1z">
                        </path>
                    </svg>
                    <a href="javascript:PopUpShow()">
                        <div class="blockTextButtonHeaderPageHome"><span>Оставить заявку на обучение</span></div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- blog posts -->

<div class="container PageStudyBlog">
    <div class="row">
        <div class="col-lg-8">
            <div class="row">
                <?php $count = 0;
                if (have_posts()):
                    while (have_posts()):
                        the_post();
                        $count++;

                        switch ($count) {
                            case "1": ?>
                                <div class="col-lg-12">
                                    <div class="blockAuthorAndDate">
                                        <p>
                                            <?php the_author(); ?>
                                        </p>
                                        <p>
                                            <?php the_time('j F Y'); ?>
                                        </p>
                                    </div>
                                    <div class="contentBlogPost">
                                        <a href="<?php echo get_the_permalink(); ?>" class="h4 headerTextBlogPost">
                                            <?php the_title(); ?>
                                        </a>
                                        <p>
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                    <a href="<?php echo get_the_permalink(); ?>" class="readMore">Смотреть</a>
                                    <hr>
                                </div>
                                <?php
                                break;
                            default: ?>
                                <div class="col-lg-6">
                                    <div class="blockAuthorAndDate">
                                        <p>
                                            <?php the_author(); ?>
                                        </p>
                                        <p>
                                            <?php the_time('j F Y'); ?>
                                        </p>
                                    </div>
                                    <div class="contentBlogPost">
                                        <a href="<?php echo get_the_permalink(); ?>" class="h4 headerTextBlogPost">
                                            <?php the_title(); ?>
                                        </a>
                                        <p>
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                    <a href="<?php echo get_the_permalink(); ?>" class="readMore">Смотреть</a>
                                    <hr>
                                </div>

                                <!-- Вывод постов, функции цикла: the_title() и т.д. -->

                        <?php }endwhile; else: ?>
                    Записей нет.
                <?php endif; ?>
            </div>

            <!-- навигация по записям постов -->

            <?php the_posts_pagination(
                array(
                    'prev_text' => __('<span class="p-2">« Назад</span>'),
                    'next_text' => __('<span class="p-2">Следующая »</span>'),
                    'before_page_number' => '<span class="p-2">',
                    'after_page_number' => '</span>'
                )
            ); ?>
        </div>

        <!-- widget sidebar blog -->

        <aside class="col-lg-4">
            <?php if (!dynamic_sidebar('sidebar-blog')):

                dynamic_sidebar('sidebar-blog');

            endif; ?>

        </aside>
    </div>
</div>


<?php get_footer(); ?>